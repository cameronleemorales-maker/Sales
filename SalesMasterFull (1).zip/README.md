# SalesMaster (Android)

- Kotlin, Navigation, Material
- Tabs: Home, Training (calls OpenAI Chat Completions), Rebuttals
- Configure your OpenAI key via:
  - **GitHub Actions secret** `OPENAI_API_KEY` (for CI builds), or
  - Local gradle property `OPENAI_API_KEY=sk-...` in `~/.gradle/gradle.properties`.

## Build locally
```
./gradlew assembleDebug
```

## CI
This repo includes `.github/workflows/android.yml`. It builds the APK and uploads it as an artifact.
