package com.salesmaster.app

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.salesmaster.app.databinding.FragmentTrainingBinding
import kotlinx.coroutines.launch

class TrainingFragment : Fragment() {
    private var _binding: FragmentTrainingBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTrainingBinding.inflate(inflater, container, false)

        binding.askButton.setOnClickListener {
            val prompt = binding.inputPrompt.text.toString().trim()
            if (prompt.isNotEmpty()) {
                binding.outputText.text = "Thinking..."
                viewLifecycleOwner.lifecycleScope.launch {
                    val reply = OpenAIClient.getReply(requireContext(), prompt)
                    binding.outputText.text = reply ?: "No response."
                }
            }
        }

        return binding.root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
