package com.salesmaster.app

import android.content.Context
import com.google.gson.annotations.SerializedName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

object OpenAIClient {

    private const val BASE_URL = "https://api.openai.com/"

    private fun httpClient(apiKey: String): OkHttpClient {
        return OkHttpClient.Builder()
            .addInterceptor(object : Interceptor {
                override fun intercept(chain: Interceptor.Chain): Response {
                    val req = chain.request().newBuilder()
                        .addHeader("Authorization", "Bearer $apiKey")
                        .addHeader("Content-Type", "application/json")
                        .build()
                    return chain.proceed(req)
                }
            }).build()
    }

    private fun service(apiKey: String): OpenAIService {
        val retrofit = Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(httpClient(apiKey))
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        return retrofit.create(OpenAIService::class.java)
    }

    suspend fun getReply(context: Context, prompt: String): String? = withContext(Dispatchers.IO) {
        val key = BuildConfig.OPENAI_API_KEY
        if (key.isNullOrBlank()) return@withContext "No API key configured."
        val req = ChatRequest(
            model = "gpt-3.5-turbo",
            messages = listOf(
                ChatMessage("system", "You are SalesMaster AI. Answer briefly for sales rebuttals."),
                ChatMessage("user", prompt)
            )
        )
        val resp = service(key).chat(req)
        val content = resp.choices.firstOrNull()?.message?.content
        content
    }
}

data class ChatRequest(
    val model: String,
    val messages: List<ChatMessage>
)

data class ChatMessage(
    val role: String,
    val content: String
)

data class ChatResponse(
    val choices: List<Choice>
) {
    data class Choice(
        val index: Int,
        val message: ChatMessage
    )
}

interface OpenAIService {
    @POST("v1/chat/completions")
    suspend fun chat(@Body body: ChatRequest): ChatResponse
}
