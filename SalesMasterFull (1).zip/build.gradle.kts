// Intentionally minimal. All config is in app/build.gradle.kts
